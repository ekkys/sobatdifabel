<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$_doctypes = array(
					'html5'			=> '<!DOCTYPE html>'
					);

/* End of file doctypes.php */
/* Location: ./application/config/doctypes.php */