<?php
class About extends CI_Controller{

	
	function index(){
	
		$this->load->view('front/v_tentang');
	}
}