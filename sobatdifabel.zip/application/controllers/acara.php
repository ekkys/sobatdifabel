<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Acara extends CI_Controller {
	
	public function index(){
		
		$this->load->view('front/v_acara');
	}
}