                        <li>
                            <a href="<?php echo base_url() . '' ?>" class="">Beranda</a>
                        </li>
                        <li>
                            <a href="#">Profil</a>
                            <ul>
                                <li>
                                    <a href="<?php echo base_url() . 'about'; ?>"><span>&nbsp;&nbsp;&nbsp;- </span>Tentang Kami</a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url() . '#'; ?>"><span>&nbsp;&nbsp;&nbsp;- </span>Struktur Organisasi</a>
                                </li>
    
                            </ul>
                        </li>
                        <li>
                            <a href="#">Kegiatan</a>
                            <ul>
                                <li>
                                    <a href="<?php echo base_url() . 'acara'; ?>"><span>&nbsp;&nbsp;&nbsp;- </span>Acara</a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url() . 'publikasi'; ?>"><span>&nbsp;&nbsp;&nbsp;- </span>Publikasi</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Layanan</a>
                            <ul>
                                <li>
                                    <a href="<?php echo base_url() . 'pendampingan'; ?>"><span>&nbsp;&nbsp;&nbsp;- </span>Layanan Pendampingan</a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url() . 'konsultasi'; ?>"><span>&nbsp;&nbsp;&nbsp;- </span>Layanan Konsultasi</a>
                                </li>
                               
                                <li>
                                    <a href="<?php echo base_url() . 'alat'; ?>"><span>&nbsp;&nbsp;&nbsp;- </span>Layanan Alat Bantu</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo base_url() . 'sekolah' ?>">Sekolah Inklusi Nusantara</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url() . 'galeri' ?>">Galeri Sobat Difabel</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url() . '#' ?>">Login/Join </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url() . '#' ?>">Kontak</a>
                        </li>
                        </ul>